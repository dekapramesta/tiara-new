<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="row ">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="col">
                            <div class="row ">
                                <div class="col">
                                    <h4>About</h4>
                                </div>
                                <div class="col text-right">
                                    <button type="button" data-toggle="modal" data-target="#kelebihanModal"
                                        class="btn btn-primary">Tambah Kelebihan</button>

                                </div>

                            </div>
                            <div class="col mt-2">
                                <?php if($errors->any()): ?>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p class="alert alert-danger"><?php echo e($err); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>

                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped" id="table-1">
                                <thead>
                                    <tr>
                                        <th>
                                            No
                                        </th>
                                        <th>Kelebihan</th>
                                        <th>Deskripsi</th>

                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $no = 1;
                                    ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($no++); ?></td>
                                            <td><?php echo e($dt->title_kelebihan); ?></td>
                                            <td><?php echo e($dt->desk_kelebihan); ?></td>
                                            <td>
                                                <div class="dropdown">
                                                    <a href="#" data-toggle="dropdown"
                                                        class="btn btn-primary dropdown-toggle">Pilihan</a>
                                                    <div class="dropdown-menu">
                                                        <a onclick="EditAbout('<?php echo e($dt); ?>')"
                                                            class="dropdown-item has-icon"><i class="far fa-edit"></i>
                                                            Edit</a>
                                                        <form id="form_deleteabout<?php echo e($dt->id); ?>"
                                                            action="<?php echo e(route('about.delete', $dt->id)); ?>" method="POST"
                                                            style="display: inline-flex">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <a href="javascript:void()"
                                                                onclick="document.getElementById('form_deleteabout<?php echo e($dt->id); ?>').submit();"
                                                                class="dropdown-item has-icon"><i
                                                                    class="fas fa-user-shield"></i> Delete</a>
                                                        </form>


                                                    </div>
                                                </div>
                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="modal fade" id="kelebihanModal" tabindex="-1" role="dialog" aria-labelledby="formModal"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="formModal">Modal title</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form class="" action="<?php echo e(route('about.tambah')); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Kelebihan</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Kelebiihan"
                                        name="title_kelebihan">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Deskripsi</label>
                                <div class="input-group">
                                    <textarea name="desk_kelebihan" id=""class="form-control"></textarea>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary m-t-15 waves-effect">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="ModalEditAbout" tabindex="-1" role="dialog" aria-labelledby="formModal"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="formModal">Modal title</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form class="" action="<?php echo e(route('about.edit')); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Kelebihan</label>
                                <div class="input-group">
                                    <input type="text" id="editabout_title" class="form-control" placeholder="Nama"
                                        name="title_kelebihan">
                                    <input hidden type="text" id="editabout_id" name="id">
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Deskripsi</label>
                                <div class="input-group">
                                    <textarea name="desk_kelebihan" class="form-control" id="editabout_desk"></textarea>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary m-t-15 waves-effect">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <script>
            function EditAbout(data) {
                let dt = JSON.parse(data)
                $('#editabout_id').val(dt.id)
                $('#editabout_title').val(dt.title_kelebihan)
                $('#editabout_desk').val(dt.desk_kelebihan)
                $('#ModalEditAbout').appendTo("body").modal('show');

            }
        </script>
<?php /**PATH B:\laravel\tiara-new\resources\views/admin/about.blade.php ENDPATH**/ ?>