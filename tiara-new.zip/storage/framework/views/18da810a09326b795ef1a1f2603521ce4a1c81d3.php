<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="row ">
            
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="col">
                            <div class="row ">
                                <div class="col">
                                    <h4>Menu</h4>
                                </div>
                                <div class="col text-right">
                                    <button type="button" data-toggle="modal" data-target="#exampleModal"
                                        class="btn btn-primary">Tambah Menu</button>

                                </div>

                            </div>
                            <div class="col mt-2">
                                <?php if($errors->any()): ?>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p class="alert alert-danger"><?php echo e($err); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>

                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped" id="table-1">
                                <thead>
                                    <tr>
                                        <th>
                                            No
                                        </th>
                                        <th>Nama</th>
                                        <th>Jenis</th>
                                        <th>Harga</th>
                                        <th>Gambar</th>
                                        <th>Aksi</th>


                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $no = 1;
                                    ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($no++); ?></td>
                                            <td><?php echo e($dt->nama); ?></td>
                                            <td><?php echo e($dt->GetJenis->jenis); ?></td>
                                            <td><?php echo e($dt->harga); ?></td>
                                            <td><img src="<?php echo e(asset('image/' . $dt->gambar)); ?>" class="img-thumbnail"
                                                    alt="" style="height: 150px; width:150px"></td>
                                            <td>
                                                <div class="dropdown">
                                                    <a href="#" data-toggle="dropdown"
                                                        class="btn btn-primary dropdown-toggle">Pilihan</a>
                                                    <div class="dropdown-menu">
                                                        <a onclick="EditMenu('<?php echo e($dt); ?>')"
                                                            class="dropdown-item has-icon"><i class="far fa-edit"></i>
                                                            Edit</a>
                                                        <form id="form_delete<?php echo e($dt->id); ?>"
                                                            action="<?php echo e(route('menu.delete', $dt->id)); ?>" method="POST"
                                                            style="display: inline-flex">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <a href="javascript:{}"
                                                                onclick="document.getElementById('form_delete<?php echo e($dt->id); ?>').submit();"
                                                                class="dropdown-item has-icon"><i
                                                                    class="fas fa-user-shield"></i> Delete</a>
                                                        </form>


                                                    </div>
                                                </div>
                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="formModal"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="formModal">Modal title</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form class="" action="<?php echo e(route('menu.tambah')); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Nama</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Nama" name="nama">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Jenis</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Jenis" name="jenis">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Harga</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Harga" name="harga">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Gambar</label>
                                <div class="input-group">
                                    <input type="file" class="form-control" name="gambar" placeholder="Gambar">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Deskripsi</label>
                                <div class="input-group">
                                    <textarea name="deskripsi" class="form-control" id=""></textarea>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary m-t-15 waves-effect">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="ModalEdit" tabindex="-1" role="dialog" aria-labelledby="formModal"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="formModal">Modal title</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form class="" action="<?php echo e(route('menu.edit')); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Nama</label>
                                <div class="input-group">
                                    <input type="text" id="edit_nama" class="form-control" placeholder="Nama"
                                        name="nama">
                                    <input hidden type="text" id="edit_id" name="id">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Jenis</label>
                                <div class="input-group">
                                    <input type="text" id="edit_jenis" class="form-control" placeholder="Jenis"
                                        name="jenis">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Harga</label>
                                <div class="input-group">
                                    <input type="text" id="edit_harga" class="form-control" placeholder="Harga"
                                        name="harga">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Gambar</label>
                                <div class="input-group">
                                    <input type="file" class="form-control" name="gambar" placeholder="Gambar">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Deskripsi</label>
                                <div class="input-group">
                                    <textarea name="deskripsi" class="form-control" id="edit_desk"></textarea>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary m-t-15 waves-effect">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <script>
            function EditMenu(data) {
                let dt = JSON.parse(data)
                $('#edit_id').val(dt.id)
                $('#edit_nama').val(dt.nama)
                $('#edit_nama').val(dt.nama)
                $('#edit_harga').val(dt.harga)
                $('#edit_jenis').val(dt.jenis)
                $('#edit_desk').html(dt.deskripsi)
                $('#ModalEdit').appendTo("body").modal('show');

            }
        </script>
<?php /**PATH B:\laravel\tiara-new\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>