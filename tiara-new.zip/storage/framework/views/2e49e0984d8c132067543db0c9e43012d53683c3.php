  </div>
  </div>
  <!-- General JS Scripts -->
  <script src="<?php echo e(asset('admin/js/app.min.js')); ?>"></script>
  <!-- JS Libraies -->
  <script src="<?php echo e(asset('admin/bundles/apexcharts/apexcharts.min.js')); ?>"></script>
  <!-- Page Specific JS File -->
  <script src="<?php echo e(asset('admin/js/page/index.js')); ?>"></script>
  <!-- Template JS File -->
  <script src="<?php echo e(asset('admin/js/scripts.js')); ?>"></script>
  <!-- Custom JS File -->
  <script src="<?php echo e(asset('admin/js/custom.js')); ?>"></script>

  </body>


  <!-- index.html  21 Nov 2019 03:47:04 GMT -->

  </html>
<?php /**PATH B:\laravel\tiara-new\resources\views/admin/footer.blade.php ENDPATH**/ ?>