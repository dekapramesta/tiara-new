'use strict';
$(function () {
    $('#mainTable').editableTableWidget();
});